import cv2
import numpy as np
import serial
import time
import tkinter as tk
from tkinter import ttk
import threading
import math

# ═══════════════════════════════════════════════════════
# SHARED STATE — GUI and CV loop communicate through this
# ═══════════════════════════════════════════════════════
state_lock = threading.Lock()
shared_state = {
    "mode":        "normal",   # "normal" | "circle" | "infinity" | "sketch"
    "radius_mm":   60.0,
    "period_sec":  8.0,
    "running":     True,
    # ── NEW: sketch path ────────────────────────────────
    # List of (x_mm, y_mm) tuples drawn by the user.
    # Empty = no sketch yet → ball stays at centre.
    "sketch_path": [],
}

# ═══════════════════════════════════════════════════════
# PLATE BOUNDARY CONSTANT
# 18 cm = 180 mm — hard limit enforced on all sketch points
# ═══════════════════════════════════════════════════════
PLATE_RADIUS_MM = 90.0   # half of 18 cm diameter

# ═══════════════════════════════════════════════════════
# SERIAL PORT
# ═══════════════════════════════════════════════════════
stm_serial = serial.Serial('COM6', 115200, timeout=0)

# ═══════════════════════════════════════════════════════
# COLOUR RANGE — black ball
# ═══════════════════════════════════════════════════════
lower_ball = np.array([0,   0,   0 ])
upper_ball = np.array([180, 255, 50])

# ═══════════════════════════════════════════════════════
# DETECTION FILTERS
# ═══════════════════════════════════════════════════════
MIN_RADIUS            = 40
MAX_RADIUS            = 60
CIRCULARITY_THRESHOLD = 0.75

# ═══════════════════════════════════════════════════════
# SCALE FACTOR
# ═══════════════════════════════════════════════════════
MM_PER_PIXEL = 0.3846153846153846

# ═══════════════════════════════════════════════════════
# SMOOTHING
# ═══════════════════════════════════════════════════════
alpha    = 0.45
x_smooth = None
y_smooth = None


# ═══════════════════════════════════════════════════════
# TRAJECTORY MATHS
# ═══════════════════════════════════════════════════════
def get_setpoint(mode, elapsed, radius_mm, period_sec, sketch_path):
    """
    Returns (setpoint_x_mm, setpoint_y_mm).

    NORMAL   → (0, 0)
    CIRCLE   → parametric circle
    INFINITY → Lemniscate of Bernoulli
    SKETCH   → interpolates along recorded path at speed
                determined by period_sec
    """
    omega = 2 * math.pi / period_sec
    t     = omega * elapsed

    if mode == "circle":
        x = radius_mm * math.cos(t)
        y = radius_mm * math.sin(t)

    elif mode == "infinity":
        denom = 1 + (math.sin(t) ** 2)
        x =  radius_mm * math.cos(t)              / denom
        y =  radius_mm * math.sin(t) * math.cos(t) / denom

    elif mode == "sketch":
        if len(sketch_path) < 2:
            return 0.0, 0.0
        # Treat path as a closed loop.
        # elapsed / period_sec gives fractional position in [0, 1)
        # around the loop.
        frac = (elapsed % period_sec) / period_sec  # 0.0 → 1.0
        n    = len(sketch_path)
        # Float index into path
        fidx = frac * n
        i0   = int(fidx) % n
        i1   = (i0 + 1)  % n
        t_   = fidx - int(fidx)          # local interpolation factor
        x0, y0 = sketch_path[i0]
        x1, y1 = sketch_path[i1]
        x = x0 + t_ * (x1 - x0)
        y = y0 + t_ * (y1 - y0)

    else:  # normal
        x, y = 0.0, 0.0

    return x, y


def draw_trajectory_preview(img, cx, cy, mode, radius_mm,
                             period_sec, sketch_path):
    """Draws the full trajectory path on the annotated frame."""
    if mode == "normal":
        return

    steps  = 300
    points = []

    if mode == "sketch":
        if len(sketch_path) < 2:
            return
        for i in range(steps + 1):
            frac = i / steps
            n    = len(sketch_path)
            fidx = frac * n
            i0   = int(fidx) % n
            i1   = (i0 + 1) % n
            t_   = fidx - int(fidx)
            x0, y0 = sketch_path[i0]
            x1, y1 = sketch_path[i1]
            sx = x0 + t_ * (x1 - x0)
            sy = y0 + t_ * (y1 - y0)
            px = int(cx + sx / MM_PER_PIXEL)
            py = int(cy + sy / MM_PER_PIXEL)
            points.append((px, py))
    else:
        for i in range(steps + 1):
            t_fake = (i / steps) * period_sec
            sx, sy = get_setpoint(mode, t_fake, radius_mm,
                                  period_sec, sketch_path)
            px = int(cx + sx / MM_PER_PIXEL)
            py = int(cy + sy / MM_PER_PIXEL)
            points.append((px, py))

    for i in range(len(points) - 1):
        cv2.line(img, points[i], points[i + 1], (0, 165, 255), 1)


# ═══════════════════════════════════════════════════════
# SKETCH CANVAS WINDOW
# Opens a dedicated Tkinter canvas for freehand drawing.
# All points are clamped to PLATE_RADIUS_MM.
# ═══════════════════════════════════════════════════════

# Canvas pixel dimensions and scale
CANVAS_SIZE  = 420          # square canvas in pixels
CANVAS_R_PX  = 190          # circle radius in pixels (represents PLATE_RADIUS_MM)
# mm per canvas pixel — how many mm one canvas pixel represents
MM_PER_CPX   = PLATE_RADIUS_MM / CANVAS_R_PX   # = 90/190 ≈ 0.4737 mm/px

def clamp_to_plate(x_px, y_px, cx, cy):
    """
    Given a canvas pixel (x_px, y_px) and canvas centre (cx, cy),
    return the (x_mm, y_mm) clamped to PLATE_RADIUS_MM.
    If outside the circle the point is projected onto the boundary.
    """
    dx = x_px - cx
    dy = y_px - cy
    dist_px = math.sqrt(dx * dx + dy * dy)

    # Clamp to circle boundary if outside
    if dist_px > CANVAS_R_PX:
        scale = CANVAS_R_PX / dist_px
        dx *= scale
        dy *= scale

    x_mm = dx * MM_PER_CPX
    y_mm = dy * MM_PER_CPX
    return x_mm, y_mm


def open_sketch_window():
    """
    Opens a popup Tkinter window with a circular drawing canvas.
    User draws freely with the mouse inside the plate circle.
    Points outside are projected onto the circle boundary.
    On confirm, the path is stored in shared_state["sketch_path"].
    """
    win = tk.Toplevel()
    win.title("Free Sketch — Draw inside the circle")
    win.configure(bg="#0d0d0d")
    win.resizable(False, False)

    BG     = "#0d0d0d"
    ACCENT = "#00e5ff"
    TEXT   = "#e8e8e8"
    FONT   = ("Courier New", 10)

    tk.Label(win,
             text="Draw your path inside the plate circle.\n"
                  "Hold left mouse button and drag to sketch.\n"
                  "Click CONFIRM to save  |  CLEAR to restart.",
             bg=BG, fg=TEXT, font=FONT,
             justify="left", padx=16, pady=10).pack()

    canvas = tk.Canvas(win,
                       width=CANVAS_SIZE, height=CANVAS_SIZE,
                       bg="#111111", highlightthickness=0)
    canvas.pack(padx=16)

    CX = CANVAS_SIZE // 2
    CY = CANVAS_SIZE // 2

    # Draw plate boundary circle
    canvas.create_oval(CX - CANVAS_R_PX, CY - CANVAS_R_PX,
                       CX + CANVAS_R_PX, CY + CANVAS_R_PX,
                       outline=ACCENT, width=2)
    # Centre crosshair
    canvas.create_line(CX - 10, CY, CX + 10, CY, fill="#444444", width=1)
    canvas.create_line(CX, CY - 10, CX, CY + 10, fill="#444444", width=1)
    # Radius label
    canvas.create_text(CX + CANVAS_R_PX - 4, CY - 8,
                       text="90mm", fill=ACCENT,
                       font=("Courier New", 8), anchor="e")

    # Raw canvas pixel points collected during drawing
    raw_points_px = []   # list of (x_px, y_px) in canvas coords

    # Points converted to mm — updated on confirm
    path_mm = []

    drawing = {"active": False}

    def on_press(event):
        drawing["active"] = True
        raw_points_px.clear()
        canvas.delete("sketch")
        _add_point(event.x, event.y)

    def on_drag(event):
        if not drawing["active"]:
            return
        _add_point(event.x, event.y)

    def on_release(event):
        drawing["active"] = False

    def _add_point(x, y):
        """Clamp point to circle and add to path, draw dot on canvas."""
        # Compute clamped canvas position for visual feedback
        dx = x - CX
        dy = y - CY
        dist = math.sqrt(dx * dx + dy * dy)
        if dist > CANVAS_R_PX and dist > 0:
            scale = CANVAS_R_PX / dist
            x = int(CX + dx * scale)
            y = int(CY + dy * scale)

        # Avoid duplicate consecutive points
        if raw_points_px and raw_points_px[-1] == (x, y):
            return

        raw_points_px.append((x, y))

        # Draw small dot on canvas
        canvas.create_oval(x - 2, y - 2, x + 2, y + 2,
                           fill="#ff6b35", outline="", tags="sketch")

        # Draw line segment to previous point
        if len(raw_points_px) >= 2:
            prev = raw_points_px[-2]
            canvas.create_line(prev[0], prev[1], x, y,
                               fill="#ff6b35", width=2, tags="sketch")

    def on_confirm():
        if len(raw_points_px) < 2:
            tk.messagebox.showwarning("No path",
                "Please draw a path first.", parent=win)
            return

        # Convert all canvas pixel points to mm
        path_mm.clear()
        for px, py in raw_points_px:
            xm, ym = clamp_to_plate(px, py, CX, CY)
            path_mm.append((xm, ym))

        # Store in shared state and switch to sketch mode
        with state_lock:
            shared_state["sketch_path"] = list(path_mm)
            shared_state["mode"] = "sketch"

        status_lbl.config(text=f"✓  Path saved  ({len(path_mm)} points)",
                          fg="#00ff88")

    def on_clear():
        raw_points_px.clear()
        path_mm.clear()
        canvas.delete("sketch")
        status_lbl.config(text="Canvas cleared — draw again.", fg=TEXT)

    canvas.bind("<ButtonPress-1>",   on_press)
    canvas.bind("<B1-Motion>",       on_drag)
    canvas.bind("<ButtonRelease-1>", on_release)

    btn_frame = tk.Frame(win, bg=BG)
    btn_frame.pack(pady=10)

    tk.Button(btn_frame, text="✓  CONFIRM",
              font=("Courier New", 11, "bold"),
              bg="#003a1a", fg="#00ff88",
              activebackground="#00ff88", activeforeground="#000",
              relief="flat", bd=0, padx=16, pady=8,
              cursor="hand2",
              command=on_confirm).pack(side="left", padx=8)

    tk.Button(btn_frame, text="↺  CLEAR",
              font=("Courier New", 11, "bold"),
              bg="#2a2a2a", fg=TEXT,
              activebackground="#555", activeforeground="#000",
              relief="flat", bd=0, padx=16, pady=8,
              cursor="hand2",
              command=on_clear).pack(side="left", padx=8)

    status_lbl = tk.Label(win,
                          text="Draw a path, then click CONFIRM.",
                          bg=BG, fg=TEXT, font=FONT)
    status_lbl.pack(pady=(0, 12))


# ═══════════════════════════════════════════════════════
# CV LOOP — runs in background thread
# ═══════════════════════════════════════════════════════
def cv_loop():
    global x_smooth, y_smooth

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS,          30)
    cap.set(cv2.CAP_PROP_AUTOFOCUS,    0)
    cap.set(cv2.CAP_PROP_BUFFERSIZE,   1)

    print(f"Resolution: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}x"
          f"{cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}")
    print(f"FPS:        {cap.get(cv2.CAP_PROP_FPS)}")

    FRAME_CX = cap.get(cv2.CAP_PROP_FRAME_WIDTH)  / 2
    FRAME_CY = cap.get(cv2.CAP_PROP_FRAME_HEIGHT) / 2

    traj_start = time.time()

    while True:
        with state_lock:
            mode        = shared_state["mode"]
            radius_mm   = shared_state["radius_mm"]
            period_sec  = shared_state["period_sec"]
            running     = shared_state["running"]
            sketch_path = list(shared_state["sketch_path"])

        if not running:
            break

        ret, frame = cap.read()
        if not ret:
            break

        # ── PRE-PROCESSING — UNCHANGED ───────────────────
        blurred = cv2.GaussianBlur(frame, (5, 5), 0)
        hsv     = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
        mask    = cv2.inRange(hsv, lower_ball, upper_ball)
        mask    = cv2.erode (mask, None, iterations=1)
        mask    = cv2.dilate(mask, None, iterations=2)

        annotated = frame.copy()

        # ── CONTOUR DETECTION — UNCHANGED ────────────────
        contours, _ = cv2.findContours(mask.copy(),
                                       cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)

        valid = []
        for c in contours:
            (x, y), r = cv2.minEnclosingCircle(c)
            r = int(r)
            if r < MIN_RADIUS or r > MAX_RADIUS:
                continue
            area  = cv2.contourArea(c)
            perim = cv2.arcLength(c, True)
            if perim == 0:
                continue
            circ = (4 * np.pi * area) / (perim ** 2)
            if circ < CIRCULARITY_THRESHOLD:
                continue

            #print(f"Radius: {r}px   Circularity: {circ:.3f}")

            valid.append(c)

        # ── TRAJECTORY SETPOINT ──────────────────────────
        elapsed = time.time() - traj_start
        setpoint_x_mm, setpoint_y_mm = get_setpoint(
            mode, elapsed, radius_mm, period_sec, sketch_path)

        # ── BALL DETECTION — UNCHANGED ───────────────────
        if valid:
            ball       = max(valid, key=cv2.contourArea)
            (x, y), r  = cv2.minEnclosingCircle(ball)
            ball_x     = int(x)
            ball_y     = int(y)
            ball_r     = int(r)

            if x_smooth is None:
                x_smooth = ball_x
                y_smooth = ball_y

            x_smooth = alpha * ball_x + (1 - alpha) * x_smooth
            y_smooth = alpha * ball_y + (1 - alpha) * y_smooth

            x_mm        = (ball_x   - FRAME_CX) * MM_PER_PIXEL
            y_mm        = (ball_y   - FRAME_CY) * MM_PER_PIXEL
            x_smooth_mm = (x_smooth - FRAME_CX) * MM_PER_PIXEL
            y_smooth_mm = (y_smooth - FRAME_CY) * MM_PER_PIXEL

            error_x_mm = x_smooth_mm - setpoint_x_mm
            error_y_mm = y_smooth_mm - setpoint_y_mm

            x_send = int(error_x_mm * 10)
            y_send = int(error_y_mm * 10)
            packet = f"<{x_send},{y_send}>\n"
            stm_serial.write(packet.encode('utf-8'))

            cv2.circle(annotated, (ball_x, ball_y), ball_r, (0, 255, 0), 2)
            cv2.circle(annotated, (ball_x, ball_y), 4,      (0, 0, 255), -1)

            cv2.putText(annotated,
                        f"Error   X: {error_x_mm:.1f}mm  Y: {error_y_mm:.1f}mm",
                        (10, 40), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (0, 200, 255), 2)

        # ── CROSSHAIR ────────────────────────────────────
        cx, cy = int(FRAME_CX), int(FRAME_CY)
        cv2.line(annotated, (cx-20, cy),    (cx+20, cy),    (0, 0, 255), 1)
        cv2.line(annotated, (cx,    cy-20), (cx,    cy+20), (0, 0, 255), 1)

        # ── PLATE BOUNDARY CIRCLE ON CAMERA FEED ─────────
        # Shows operator where 90mm (18cm diameter) boundary is
        plate_r_px = int(PLATE_RADIUS_MM / MM_PER_PIXEL)
        cv2.circle(annotated, (cx, cy), plate_r_px,
                   (80, 80, 80), 1)

        # ── TRAJECTORY PREVIEW ───────────────────────────
        draw_trajectory_preview(annotated, cx, cy, mode,
                                radius_mm, period_sec, sketch_path)

        # Setpoint dot
        sp_px_x = int(cx + setpoint_x_mm / MM_PER_PIXEL)
        sp_px_y = int(cy + setpoint_y_mm / MM_PER_PIXEL)
        if mode != "normal":
            cv2.circle(annotated, (sp_px_x, sp_px_y), 8,  (255, 255, 0), -1)
            cv2.circle(annotated, (sp_px_x, sp_px_y), 11, (255, 255, 0),  1)
            cv2.putText(annotated,
                        f"Setpoint  X: {setpoint_x_mm:.1f}mm"
                        f"  Y: {setpoint_y_mm:.1f}mm",
                        (10, 70), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (255, 255, 0), 2)

        # Mode label
        mode_label = {
            "normal":   "NORMAL  |  Balance",
            "circle":   "CIRCLE  |  Trajectory",
            "infinity": "INFINITY  |  Trajectory",
            "sketch":   f"SKETCH  |  {len(sketch_path)} pts",
        }
        cv2.putText(annotated,
                    mode_label.get(mode, mode),
                    (750, 40), cv2.FONT_HERSHEY_SIMPLEX,
                    0.9, (180, 255, 180), 2)

        # ── DISPLAY ──────────────────────────────────────
        cv2.imshow("Ball Balancer — Camera", annotated)
        cv2.imshow("Mask", mask)

        if cv2.waitKey(1) & 0xFF == 27:
            with state_lock:
                shared_state["running"] = False
            break

    cap.release()
    cv2.destroyAllWindows()
    stm_serial.close()


# ═══════════════════════════════════════════════════════
# GUI — Tkinter control panel
# ═══════════════════════════════════════════════════════
def build_gui():
    root = tk.Tk()
    root.title("Ball Balancer — Control Panel")
    root.configure(bg="#0d0d0d")
    root.resizable(False, False)

    BG       = "#0d0d0d"
    CARD     = "#1a1a1a"
    ACCENT   = "#00e5ff"
    ACCENT2  = "#ff6b35"
    ACCENT3  = "#00ff88"     # green for sketch
    TEXT     = "#e8e8e8"
    MUTED    = "#666666"
    FONT_HDR = ("Courier New", 13, "bold")
    FONT_LBL = ("Courier New", 10)
    FONT_VAL = ("Courier New", 11, "bold")
    FONT_BTN = ("Courier New", 11, "bold")

    tk.Label(root, text="⬡  BALL BALANCER  ⬡",
             bg=BG, fg=ACCENT, font=("Courier New", 15, "bold"),
             pady=14).pack()
    tk.Frame(root, bg=ACCENT, height=1).pack(fill="x", padx=20)

    # ── Mode selector ────────────────────────────────────
    mode_frame = tk.Frame(root, bg=CARD, padx=20, pady=16)
    mode_frame.pack(fill="x", padx=20, pady=(16, 4))

    tk.Label(mode_frame, text="MODE",
             bg=CARD, fg=MUTED, font=FONT_LBL).pack(anchor="w")
    tk.Label(mode_frame, text="Select trajectory type",
             bg=CARD, fg=TEXT, font=FONT_HDR).pack(anchor="w", pady=(2, 10))

    mode_var = tk.StringVar(value="normal")
    btn_frame = tk.Frame(mode_frame, bg=CARD)
    btn_frame.pack(fill="x")

    mode_buttons = {}

    def set_mode(m):
        with state_lock:
            shared_state["mode"] = m
        mode_var.set(m)
        for name, btn in mode_buttons.items():
            if name == m:
                col = ACCENT3 if name == "sketch" else ACCENT
                btn.config(bg=col, fg="#000000")
            else:
                btn.config(bg="#2a2a2a", fg=TEXT)

    # ── SKETCH button opens drawing window ───────────────
    def on_sketch_btn():
        # Switch mode to sketch first so button highlights
        set_mode("sketch")
        # Open the sketch canvas popup on the main thread
        open_sketch_window()

    for label, mkey, cmd in [
        ("⊙  NORMAL",   "normal",   lambda: set_mode("normal")),
        ("◯  CIRCLE",   "circle",   lambda: set_mode("circle")),
        ("∞  INFINITY", "infinity", lambda: set_mode("infinity")),
        ("✏  SKETCH",   "sketch",   on_sketch_btn),
    ]:
        b = tk.Button(btn_frame, text=label, font=FONT_BTN,
                      bg="#2a2a2a", fg=TEXT,
                      activebackground=ACCENT, activeforeground="#000",
                      relief="flat", bd=0, padx=12, pady=8,
                      cursor="hand2",
                      command=cmd)
        b.pack(side="left", padx=(0, 6))
        mode_buttons[mkey] = b

    mode_buttons["normal"].config(bg=ACCENT, fg="#000000")

    tk.Frame(root, bg="#2a2a2a", height=1).pack(fill="x", padx=20, pady=8)

    # ── Slider helper ────────────────────────────────────
    def make_slider(parent, label, sublabel, from_, to_,
                    initial, unit, key, color=ACCENT):
        frame = tk.Frame(parent, bg=CARD, padx=20, pady=14)
        frame.pack(fill="x", padx=20, pady=4)

        header = tk.Frame(frame, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 bg=CARD, fg=MUTED, font=FONT_LBL).pack(side="left")
        val_lbl = tk.Label(header, text=f"{initial}{unit}",
                           bg=CARD, fg=color, font=FONT_VAL)
        val_lbl.pack(side="right")

        tk.Label(frame, text=sublabel,
                 bg=CARD, fg=TEXT, font=FONT_HDR).pack(anchor="w",
                                                        pady=(2, 8))

        style_name = f"{key}.Horizontal.TScale"
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(style_name,
                        background=CARD,
                        troughcolor="#2a2a2a",
                        sliderthickness=18,
                        sliderrelief="flat")

        def on_change(val):
            v = float(val)
            val_lbl.config(text=f"{v:.1f}{unit}")
            with state_lock:
                shared_state[key] = v

        slider = ttk.Scale(frame, from_=from_, to=to_,
                           orient="horizontal",
                           style=style_name,
                           command=on_change)
        slider.set(initial)
        slider.pack(fill="x")

        rl = tk.Frame(frame, bg=CARD)
        rl.pack(fill="x")
        tk.Label(rl, text=f"{from_}{unit}",
                 bg=CARD, fg=MUTED, font=FONT_LBL).pack(side="left")
        tk.Label(rl, text=f"{to_}{unit}",
                 bg=CARD, fg=MUTED, font=FONT_LBL).pack(side="right")

    make_slider(root,
                label="RADIUS",
                sublabel="Trajectory radius  (circle & infinity)",
                from_=10, to_=110, initial=60.0,
                unit=" mm", key="radius_mm", color=ACCENT)

    make_slider(root,
                label="PERIOD",
                sublabel="Time for one full cycle  (all trajectory modes)",
                from_=2, to_=20, initial=8.0,
                unit=" s", key="period_sec", color=ACCENT2)

    tk.Frame(root, bg="#2a2a2a", height=1).pack(fill="x", padx=20, pady=8)

    # ── Sketch info card ─────────────────────────────────
    sk_frame = tk.Frame(root, bg=CARD, padx=20, pady=12)
    sk_frame.pack(fill="x", padx=20, pady=4)

    tk.Label(sk_frame, text="SKETCH MODE",
             bg=CARD, fg=MUTED, font=FONT_LBL).pack(anchor="w")
    tk.Label(sk_frame,
             text="Click  ✏ SKETCH  to open the drawing canvas.\n"
                  "Draw your path inside the 18 cm plate circle.\n"
                  "Period slider controls playback speed.",
             bg=CARD, fg=TEXT, font=("Courier New", 9),
             justify="left").pack(anchor="w", pady=(4, 0))

    tk.Frame(root, bg="#2a2a2a", height=1).pack(fill="x", padx=20, pady=8)

    # ── Hints ────────────────────────────────────────────
    hints = tk.Frame(root, bg=BG, padx=20, pady=6)
    hints.pack(fill="x")
    for txt, col in [
        ("↓ period  =  faster motion",         ACCENT2),
        ("sketch boundary  =  90 mm radius",   ACCENT3),
        ("ESC in camera window  =  quit",       MUTED),
    ]:
        tk.Label(hints, text=txt, bg=BG, fg=col,
                 font=FONT_LBL, anchor="w").pack(fill="x")

    # ── Quit ─────────────────────────────────────────────
    def on_quit():
        with state_lock:
            shared_state["running"] = False
        root.after(300, root.destroy)

    tk.Button(root, text="■  STOP & QUIT",
              font=FONT_BTN,
              bg="#3a0000", fg="#ff4444",
              activebackground="#ff4444", activeforeground="#000",
              relief="flat", bd=0, padx=20, pady=10,
              cursor="hand2",
              command=on_quit).pack(pady=(4, 16))

    root.mainloop()


# ═══════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════
if __name__ == "__main__":
    cv_thread = threading.Thread(target=cv_loop, daemon=True)
    cv_thread.start()

    build_gui()

    with state_lock:
        shared_state["running"] = False
    cv_thread.join(timeout=3)
    print("Shutdown complete.")